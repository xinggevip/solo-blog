title: java部署坑真TM的多
date: '2019-10-21 16:56:17'
updated: '2019-10-21 16:56:17'
tags: [java项目部署]
permalink: /articles/2019/10/21/1571648177133.html
---
![](https://img.hacpai.com/bing/20190808.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

部署步骤
一、把war包放到wabapps下，再刷新会发新war包已自动解压
二、再java项目管理起创建项目，目录为webapps下的项目目录
三、点击映射，会发现在网站管理有了添加的网站
四、在网站管理中设置反向代理
五、访问测试
注意：如果更改了配置文件需要在java项目管理器重载配置
