title: 我在 GitHub 上的开源项目
date: '2019-10-23 16:47:19'
updated: '2019-10-23 16:47:19'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [IdeaJava](https://github.com/xinggevip/IdeaJava) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/IdeaJava/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/IdeaJava/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/IdeaJava/network/members "分叉数")</span>

用Idea编辑器做的java Study项目



---

### 2. [xinggevip.github.io](https://github.com/xinggevip/xinggevip.github.io) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/xinggevip/xinggevip.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/xinggevip.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/xinggevip.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.qiangssvip.com`](https://blog.qiangssvip.com "项目主页")</span>

我的静态博客



---

### 3. [JavaStudy](https://github.com/xinggevip/JavaStudy) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/JavaStudy/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/JavaStudy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/JavaStudy/network/members "分叉数")</span>

java学习笔记



---

### 4. [Docs](https://github.com/xinggevip/Docs) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/Docs/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/Docs/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/Docs/network/members "分叉数")</span>

教程、api文档、笔记、收藏



---

### 5. [jQueryNote](https://github.com/xinggevip/jQueryNote) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/jQueryNote/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/jQueryNote/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/jQueryNote/network/members "分叉数")</span>

笔记



---

### 6. [Summary](https://github.com/xinggevip/Summary) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/Summary/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/Summary/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/Summary/network/members "分叉数")</span>

复习



---

### 7. [BootstrapDemo](https://github.com/xinggevip/BootstrapDemo) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/BootstrapDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/BootstrapDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/BootstrapDemo/network/members "分叉数")</span>

新闻站



---

### 8. [BootstrapStudy](https://github.com/xinggevip/BootstrapStudy) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/BootstrapStudy/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/BootstrapStudy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/BootstrapStudy/network/members "分叉数")</span>

bootstrap学习笔记



---

### 9. [SassStudy](https://github.com/xinggevip/SassStudy) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xinggevip/SassStudy/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xinggevip/SassStudy/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xinggevip/SassStudy/network/members "分叉数")</span>

sass学习笔记

